# NextGen Fiesta Server Manager

Windows-GUI zur Diagnose und Administration von Fiesta **NA2016** Servern.

## 0.3.4 – Hardware-aware Scaling, Adaptive Hooks & Capacity-Fix


### Neu in 0.3.4

- Hardware-Profil im Performance-Tab: CPU-Modell, nominaler Takt, logische CPUs, NUMA-Nodes, Host-CPU sowie physischer RAM
- automatische Einordnung **Single-Core/Mainthread**, **RAM**, **Parallelität** oder **vertikale Reserve**
- wichtig für Dual-Socket: ein zweiter CPU-Sockel erhöht primär die Zahl parallel laufender Zone-Prozesse, nicht die Geschwindigkeit eines einzelnen Zone-Mainthreads
- Capacity-Falschpositiv behoben: Runtime-Recovery und NPC-Pool hatten versehentlich denselben `NG-ZONE-0020`-Code
- `Closed ZN from` zählt nicht mehr als Pool-/Map-Hardlimit
- frische Hard-Limit-Alarme aus Logdateien verlangen jetzt zusätzlich eine aktuelle Dateischreibzeit
- weitere Zone-Binary-Analyse dokumentiert 13 exakte Pool-Count/Stride-Allokationen im zentralen Initialisierungsblock
- neuer `docs/R720_CPU_GUIDE.md`: bevorzugt **2× Xeon E5-2667 v2** für hohe Fiesta-Pro-Kern-Leistung

> **Build-Fix 0.2.3:** Der Windows-Compilerlauf aus 0.2.2 zeigte projektweit fehlende `System.IO`-Symbole (`File`, `Path`, `Directory`, `FileStream` usw.) sowie einen nullable PID-Typfehler. 0.2.3 behebt das zentral über `GlobalUsings.cs` und `int?`. Siehe `BUILD_FIX_0.2.3.md`.

### Neu in 0.3.2

- neuer Tab **Performance / Vertical Scaling** für alle Kernprozesse und Zonen
- PE32-/LARGE_ADDRESS_AWARE-Prüfung direkt aus den Server-Binaries
- PDB-basierte Architekturhinweise auf `CIOCP::WorkThread`, `ZoneServer::zs_mainthreadfunction` und `WorldManagerServer::MainThread`
- Live-Bewertung von CPU-Core-Druck, Private/Virtual Memory, Threads, Handles und Sessions
- konservatives lineares CPU-Kapazitätsmodell bei realer Last (nur als Frühindikator, nicht als Garantie)
- konkrete Tuning-Kandidaten für WM-Sessions, ShinePlayer, ShineMob, ShineNPC, MapBlockInformation und MapCluster
- berechneter zusätzlicher Rohspeicher bei Poolerhöhungen
- klare Trennung: **Config-Tuning**, **Binary/Hook nötig**, **Mainthread/CPU-Grenze**, **32-Bit-Adressraum**
- keine automatischen Binary-Patches; Änderungen werden zunächst nur bewertet und geplant

- Live-Auslastung pro `ZoneNN`: etablierte Client-TCP-Sessions gegen den verifizierten 1500er ShinePlayer/Listener-Rahmen
- CPU als Gesamtmaschinen- und **Core-äquivalenter** Wert, damit ein einzelner gesättigter Zone-Thread auf vielen CPU-Kernen nicht fälschlich harmlos aussieht
- Working Set, Private Bytes und Virtual Memory pro Zone
- konfigurierte Maps pro Zone gegen den verifizierten `MapBlockInformation`-Container (256)
- Trendfenster über zehn Minuten mit Frühwarnung, Ausbauempfehlung und kritischer Stufe
- harte Log-Grenzfehler (`ShinePlayer full`, `Too many mob/npc/mapcluster/BlockDistribute`) fließen direkt in die Skalierungsbewertung ein
- sicherer **Neue-Zone-Planer** mit automatischer nächster Zone-ID und freiem 3-Port-Block
- transaktionale Zone-Provisionierung: ServerInfo-Backup, Template-Klon ohne Logs, `MY_SERVER`/`SERVER_INFO`, Service-Registrierung, Recovery
- Windows-Firewall: nur der neue **Client-Port** wird eingehend freigegeben; interner Zone-Port und OPTool bleiben absichtlich nicht extern geöffnet
- neue Zone wird nach Provisionierung **nicht automatisch gestartet** und Maps werden nicht automatisch verschoben

Die Standard-Schwellen sind 70 % Warnung, 85 % Ausbauempfehlung und 95 % kritisch. Das 3072-MB-Private-Memory-Budget ist eine konservative Betriebswarnung, kein behauptetes Binary-Hardlimit.


Der aktuelle Stand erweitert den ursprünglichen Service-Manager um eine echte Laufzeit-Timeline und zeitliche Fehlerkorrelation:

- automatische Erkennung von Account, AccountLog, Login, Character, GameLog, WorldManager, GamigoZR und beliebig vielen `ZoneNN`-Ordnern
- Windows-Service-Status, PID, Startzeit und Port-Health
- **CPU, RAM, Handles, Threads und Port→PID-Zuordnung** pro Dienst
- Start / Stop / Neustart pro Dienst
- Dienst löschen (nur SCM-Eintrag; Dateien bleiben erhalten)
- native NA2016-Neuinstallation eines Dienstes über denselben Mechanismus wie `_Install Services.ps1`
- Service-Recovery konfigurieren
- Smart Start / Smart Stop / Smart Restart mit Abhängigkeiten
- **WorldManager-Readiness über Port + aktuellen `SUCCESSED RUNNING SERVER`-Logmarker**
- sequentieller Zone-Start mit 3-Sekunden-Stabilitätsprüfung und einem Recovery-Versuch
- Parser für `9Data/ServerInfo/ServerInfo.txt`
- Plausibilitätsprüfung von `ZoneServerInfo/ZoneServerInfo.txt`
- Erkennung von Port-Kollisionen und Port-PID-Mismatches
- Log-Analyse mit eigenen `NG-*` Fehlercodes und Reparaturanweisungen
- Dekodierung von `dep/cmd/length`; u.a. `29/149 -> 0x7495 -> NC_GUILD_GUILDWARSTATUS_REQ`
- **Live-Tail** für Message/Dbg/Error-Logs mit FileSystemWatcher + Polling-Fallback
- **Runtime-Timeline** für RUNNING/STOPPED/PID-Wechsel
- Korrelation von **Reconnect-Bursts, Crash-Loops und WM↔Zone-Startup-Races**
- Windows Event Log Analyse (`Application Error`, Service Control Manager 7031/7034)
- Referenz-Audit der mitgelieferten NA2016-EXEs via SHA-256
- Erkennung eines Zone.exe Versionsmixes
- optionale PDB-Symbolindexierung mit `llvm-pdbutil`

## Voraussetzungen

### Zum Bauen

Pflicht:

- Windows 10/11 oder Windows Server
- **.NET 8 SDK**

Optional:

- Visual Studio Community mit **.NET Desktop Development**
- LLVM (`llvm-pdbutil.exe`) für die tiefe PDB-Symbolsuche

Die Build-Anleitungen stehen in:

- `docs/BUILD_QUICKSTART.md` – kurz und direkt
- `docs/BUILD_WINDOWS.md` – vollständig mit Downloads, winget, Visual Studio und Fehlerbehebung

Automatische Installation des Pflicht-SDKs:

```powershell
.\scripts\Install-Build-Prerequisites.ps1
```

## Schnellstart

Auf einem Windows-Rechner mit .NET 8 SDK:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\scripts\Check-Prerequisites.ps1
.\Launch.ps1
```

Beim ersten Start wird Release automatisch veröffentlicht und anschließend mit Administratorrechten geöffnet.

## Release bauen

```powershell
.\scripts\Build.ps1
```

Self-contained Single File:

```powershell
.\scripts\Publish-SelfContained.ps1
```

Ausgabe:

```text
src\NextGen.Fiesta.ServerManager\bin\Release\net8.0-windows\win-x64\publish\
```

## Erster Server-Test

1. Programm als Administrator öffnen.
2. Als `Server Root` den Ordner auswählen, der `9Data`, `WorldManager`, `Zone00` usw. enthält.
3. `Scannen` drücken.
4. `Vollanalyse` ausführen.
5. Im Tab **Live Timeline** Live-Monitor prüfen/starten.
6. Für normale Starts bevorzugt **Smart Start** statt des originalen `Start Services.ps1` verwenden.
7. Besonders Zone03 beobachten: Statuswechsel, PID-Wechsel, Port und letzte Logmeldung werden zeitlich zusammengeführt.

## Smart Start 0.2

Der Manager verlässt sich nicht mehr nur auf einen offenen WM-Port:

```text
Core Services
   ↓
WorldManager RUNNING
   ↓
WM interner Zone-Port offen
   ↓
aktueller "SUCCESSED RUNNING SERVER" Marker
   ↓
Zone00 starten → 3s stabil
   ↓
Zone01 starten → 3s stabil
   ↓
...
   ↓
ZoneNN
```

Wenn der aktuelle WM-Ready-Logmarker nicht gefunden werden kann, wird ein konservatives Stabilitätsfenster verwendet. Stirbt eine Zone beim ersten Versuch, erfolgt genau **ein** kontrollierter Recovery-Start.

## Live-Korrelation

Beispiele für automatisch erzeugte Diagnosen:

- `NG-ZONE-0016` – Crash-/Restart-Schleife
- `NG-ZONE-0017` – wahrscheinliches WM↔Zone-Startup-Race
- `NG-ZONE-0020` – Zone nach Ausfall wiederhergestellt
- `NG-NET-0010` – S2S-Reconnect-Burst
- `NG-PROTO-0010` – Parser-/Sessionfehler außerhalb der Startup-Phase
- `NG-OS-0001` – Windows meldet Prozessabsturz
- `NG-SVC-0003` – Service Control Manager meldet unerwartetes Dienstende

## Sicherheitsverhalten

- `Dienst löschen` löscht **nur** den Windows-Service, nicht die Zone-Dateien.
- `Neu installieren` stoppt und löscht den Service, lässt Dateien stehen und registriert die vorhandene EXE erneut.
- automatische Änderungen an `ZoneServerInfo.txt` erzeugen vorher ein Backup in `.nextgen-backups`.
- das Tool patcht keine Fiesta-EXE.
- PDB-Indexierung ist nur lesend.
- Windows Event Logs werden nur gelesen.

## Status

Aktueller Stand: **0.3.3**. Der Manager kombiniert Service-/Port-/Log-/PDB-Diagnose, harte Zone/WM-Limits, rekursive Logerkennung, Client-/Terrain-Sicherheitsanalyse, Live-Zonen-Skalierung und Vertical-Scaling-Audit. Nächste Stufen sind reproduzierbare Lasttests, Live-Poolzähler aus Zone/WM und die vollständige verifizierte Zone-Handle-Rebase-Matrix für sichere Binary-Hooks. Siehe `docs/ROADMAP.md` und `docs/PERFORMANCE_TUNING.md`.

## 0.2.8 - Rekursive Logerkennung

Der Manager durchsucht Service-Ordner jetzt rekursiv nach NA2016-Logs und ist nicht mehr auf
`Message.txt`/`Dbg.txt` im Hauptordner beschränkt. Details: `docs/LOG_DISCOVERY.md`.


## 0.2.9 – Capacity / Map Limits

Der Tab **Limits / Capacity** zeigt hart verifizierte NA2016-Puffer und Objektpools sowie eine automatische Analyse aller `9Data\Shine\BlockInfo\*.shbd`. Der Manager liest den SHBD-Header (Int32 X-Bytes, Int32 Y-Zeilen), validiert die Payload-Größe und berechnet Kollisionsgrid und die vom Zone-Server verwendete Blockfläche.

Neu verifiziert: ShinePlayer 1500, ShineMob 8000, ShineNPC 256 sowie weitere Objektpools. Die Kartenanalyse trennt bewusst `Field.txt`-Metadaten von SHBD/BlockInfo-Abmessungen.


## 0.3.0 – Client / Map Safety

Der neue Tab prüft die konkrete `Fiesta.bin`, erkennt die bekannte NA2016-Baseline, inventarisiert vorhandene `resmap/**/*.ini`-HeightMaps und berechnet Vergleichsprofile von 64 bis 4096 Terrain-Quads. Der Manager unterscheidet zwischen dem dynamischen Terrainformat und den praktisch kritischeren Koordinaten-/Gameplay-/Packetpfaden. Für einen unveränderten NA2016-Client wird 512×512 als konservatives Produktionsziel geführt; 1024×1024 wird nur als Research-/Patchbereich behandelt.

Siehe `docs/CLIENT_MAP_LIMITS.md`.

## Adaptive Hooks (0.3.3)

Der Tab **Adaptive Hooks** macht aus der Kapazitätsanalyse einen geschützten Tuning-Workflow. Er kann WorldManager-Client/S2S-Kapazitäten und das Zone-Listener-`nMaxAccept` mit automatischen Backups anpassen und bewertet die Zielwerte gegen CPU pro Kern, 32-Bit-Private-Memory, Gesamt-CPU und freien physischen RAM.

Beim exakt verifizierten NA2016-WorldManager kann der Manager außerdem `m_MaxSessions`/`m_NumSessions` lesen und `g_UserLimit` live setzen. Eine Vergrößerung des harten WM-Sessionpools bleibt eine Startoperation über `ServerInfo.txt`, weil `InitSessions(maxSessions)` den Pool beim Start dynamisch allokiert.

Die Zielwerte für ShinePlayer/ShineMob/ShineNPC werden bereits bewertet, unvollständige Binary-Patches bleiben aber gesperrt, bis sämtliche abhängigen 16-Bit-Objekthandle-Basen in einem atomaren Patchprofil enthalten sind. Siehe `docs/ADAPTIVE_HOOKS.md`.
